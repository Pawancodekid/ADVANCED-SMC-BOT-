# Advanced SMC MT5 Bot

This bot uses Smart Money Concepts to provide high-quality signals.